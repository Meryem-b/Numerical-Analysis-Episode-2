function eigValue=invPowerMethod(A,b,TOL,q)
x=b;
n=size(A);
%q=(x'*A*x)/(x'*x);
k=1;
N=0;
for i=1:width(A)
    if(abs(x(i))==max(abs(x)))
        seq(k)=i;
        k=k+1;
    end
end
k=1;
p=min(seq);
x=x/x(p);
s=(A-q*eye(n));
if(det(s)~=0)
    error=1;
    while(N<=1000)
        y=inv(s)*x;
        m=y(p);
        error=norm(x-y/y(p));
        x=y/y(p);
         N=N+1;
    end
    if(error<=TOL)
        m=(1/m)+q;

    end
end
eigValue=m;
fprintf('Eigenvalue by inverse Power Method = %f\n',eigValue);
end


