clear all;
clc;
A=[20,5,1,-1,1,5;
    -2,8,0,-1,0,1;
   -5,3,-21,-2,-4,5;
       4,-2,5,-25,-5,0;
    1,-4,2,1,16,4;
    2,-1,5,0,-4,-24];
B=[22;12;-68;20;-25;67];
[R,C]=size(A);
x0=[1;0;1;0;1;1];
k=0;
N=0;
error=1;
while(abs(error)>realpow(10,-4))
for i=1:R
    k1=0;
    k2=0;
    for j=1:i-1
        k1=k1+A(i,j)*X(j);
    end
    for j=i+1:R
        k2=k2+A(i,j)*x0(j);
    end
    X(i)=(1/A(i,i))*(B(i)-k1-k2);
end
N=N+1;
error=norm(X)-norm(x0);
if(abs(error)<=realpow(10,-4))
    X
    x0
    error
    return;
else
    x0=X;
end
end
        
