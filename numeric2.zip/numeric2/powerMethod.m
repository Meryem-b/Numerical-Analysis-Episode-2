function eigValue = powerMethod (A,b,TOL)
    k=1;
    x=b;
    error=1;
    N=0;
    for i=1:length(A)
        if(x(i)==max(x))
            p=i;
            break;
        end
    end
    x=x/x(p);
    while(N<=1000)
        y=A*x;
        m=y(p);
            for i=1:length(A)
             if(x(i)==max(x))
                p=i;
              break;
             end
            end
        error=norm(x-(y/y(p)));
        x=y/y(p);
        if(error<=TOL)
            eigValue=m;
        end
        N=N+1;
    end

end
        
