clear all;
clc;
A=[ 1,-4,2,1,-5,4;
    0,5,1,-1,1,5;
  -2,-1,0,-1,0,1;
  -5,3,5,-2,-4,5;
  4,-2,5,3,-5,0;
  2,-1,5,0,-4,3]
B=[-4,2,-6,10,20,13];
matrixSize=length(A);
Lower=zeros(size(A));
Upper=zeros(size(A));
 
Lower(:,1)= A(:,1);
Upper(1,:)=A(1,:)/Lower(1,1);
 
Upper(1,1)=1;
 
for k=2:matrixSize
for j=2:matrixSize
    for i=j:matrixSize
        Lower(i,j)=A(i,j) - dot(Lower(i,1:j-1),Upper(1:j-1,j));
    end
    Upper(k,j)=(A(k,j)-dot(Lower(k,1:k-1),Upper(1:k-1,j)))/Lower(k,k);
end
end
 
Upper
Lower
 
% L * Y = B
Y = zeros(matrixSize, 1);
Y(1) = B(1);
for row = 2 : matrixSize  
    Y(row) = B(row);
    for col = 1 : row - 1      
        Y(row) = Y(row) - Lower(row, col) * Y(col);
    end
    Y(row) = Y(row) / Lower(row, row)
end 
Y
 
 
 
% U * X = Y
X = zeros(matrixSize, 1);
 
X(matrixSize) = Y(matrixSize) / Upper(matrixSize,matrixSize);
 
for row = matrixSize - 1 : -1 : 1
    temp = 0;
    for col = matrixSize : -1 : 1
        temp  = temp + Upper(row,col) * X(col);
    end
    X(row) = (Y(row) - temp) / Upper(row,row);
end 
 
X
    